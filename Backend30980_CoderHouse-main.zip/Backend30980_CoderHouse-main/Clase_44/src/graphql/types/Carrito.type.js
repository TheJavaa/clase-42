export const CarritoType = `
    type Carrito {
        id: ID!
        timestamp: String
    }
`