export const ProductoUpdateInput = `
    input ProductoUpdateInput {
        title: String
        price: Int
        description: String
        code: String
        image: String
        stock: Int
    }
`