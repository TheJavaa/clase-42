export const ProductoNewInput = `
    input ProductoNewInput {
        title: String!
        price: Int!
        description: String!
        code: String!
        image: String
        stock: Int!
    }
`