export const GetAllProductsFromCartByIdQuery = `
    getAllProductsFromCartById(id:ID!): [Producto]
`