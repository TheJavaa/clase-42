export const GetAllCarritosQuery = `
    getAllCarritos: [Carrito]
`
