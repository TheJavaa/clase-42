export const GetProductByIdQuery = `
    getProductById(id:ID!): Producto
`