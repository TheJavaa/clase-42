export const GetAllProductosQuery = `
    getAllProductos: [Producto]
`