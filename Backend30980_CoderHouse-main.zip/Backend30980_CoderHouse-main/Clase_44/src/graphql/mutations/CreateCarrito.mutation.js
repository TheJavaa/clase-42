export const CreateCarritoMutation = `
    createCarrito: Carrito
`