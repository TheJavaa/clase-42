export const DeleteProductByIdMutation = `
    deleteProductById(id:ID!): Producto
`