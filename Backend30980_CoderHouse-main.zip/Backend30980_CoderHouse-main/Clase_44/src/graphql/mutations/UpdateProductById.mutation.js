export const UpdateProductByIdMutation = `
    updateProductById(id:ID!, data: ProductoUpdateInput): Boolean
`