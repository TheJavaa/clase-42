export const SaveProductToCartMutation = `
    saveProductToCart(id:ID!, idProd:ID!): Boolean
`

