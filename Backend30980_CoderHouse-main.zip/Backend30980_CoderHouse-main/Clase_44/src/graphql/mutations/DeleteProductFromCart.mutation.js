export const DeleteProductFromCartMutation = `
    deleteProductFromCart(id:ID!, idProd:ID!): Boolean
`