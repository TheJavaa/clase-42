export const DeleteCarritoByIdMutation = `
    deleteCarritoById(id:ID!): Carrito
`