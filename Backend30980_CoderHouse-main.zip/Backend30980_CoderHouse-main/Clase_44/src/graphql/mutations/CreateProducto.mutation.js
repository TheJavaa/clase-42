export const CreateProductoMutation = `
    createProduct(data: ProductoNewInput): Producto
`