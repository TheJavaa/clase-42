const sqlite3 = {
    client: 'sqlite3',
    connection: { filename: "./db/proyecto.sqlite3" },
    useNullAsDefault: true
};

export default sqlite3;


