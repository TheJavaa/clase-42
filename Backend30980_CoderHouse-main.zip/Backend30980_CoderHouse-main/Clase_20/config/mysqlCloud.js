const mysqlCloud = {
    client: 'mysql',
    connection: {
        host: 'bm2nyjdxjvajhkk8iwy3-mysql.services.clever-cloud.com',
        user: 'ubpt0hezntj8cjvd',
        password: 'M6JvzaxHp8C0bOGsL17a',
        database: 'bm2nyjdxjvajhkk8iwy3'
    }
}

export default mysqlCloud;
