const mysql = {
  client: "mysql",
  connection: {
    host: "localhost",
    user: "root",
    password: "",
    database: "test",
  },
};

module.exports = mysql;