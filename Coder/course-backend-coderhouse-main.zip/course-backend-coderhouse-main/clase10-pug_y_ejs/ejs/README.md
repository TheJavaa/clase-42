# EJS

Realizar el mismo ejercicio que en el desafío anterior, utilizando `ejs`.
