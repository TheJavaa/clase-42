# Fecha y hora

-   Realizar un programa que:
    1. Guarde en un archivo llamado fyh.txt la fecha y hora actual.
    2. Lea nuestro propio archivo de programa y lo muestre por consola.
    3. Incluya el manejo de errores con try catch (progresando las excepciones con throw new Error).

**Aclaración**: utilizar las funciones sincrónicas de lectura y escritura de archivos del módulo fs de node.js
