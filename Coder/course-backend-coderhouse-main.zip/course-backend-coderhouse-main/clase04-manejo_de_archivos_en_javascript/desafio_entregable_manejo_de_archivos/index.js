const Contenedor = require('./Contenedor.js');

const products = new Contenedor('products.txt');

const test = async () => {
	// const getall = await products.getAll();
	// console.log({ getall });
	// const save = await products.save({
	// 	title: 'product name',
	// 	price: Date.now(),
	// 	thumbnail: 'url product photo'
	// });
	// console.log({ save });
	// const getbyid = await products.getById(4);
	// console.log({ getbyid });
	// const deletebyid = await products.deleteById(3);
	// console.log({ deletebyid });
	// const deleteall = await products.deleteAll();
	// console.log({ deleteall });
};

test();
