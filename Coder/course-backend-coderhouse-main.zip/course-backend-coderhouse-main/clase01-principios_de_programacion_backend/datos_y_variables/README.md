# Datos y Variables

1. Definir variables variables que almacenen los siguiente datos:

-   Un nombre: “pepe”
-   Una edad: 25
-   Un precio: $99.90
-   Los nombres de mis series favoritas: “Dark”, “Mr Robot”, “Castlevania”
-   Mis películas favoritas, en donde cada película detalla su nombre,
    el año de estreno, y una lista con los nombres de sus protagonistas.

1. Mostrar todos esos valores por consola
2. Incrementar la edad en 1 y volver a mostrarla
3. Agregar una serie a la lista y volver a mostrarla
