# Despliegue en Glitch

Realizar el despliegue de la aplicación de chat colaborativo realizado en el desafío anterior en la plataforma Glitch.com

[Despliegue en Glitch](https://cheerful-ivy-gondola.glitch.me/)
