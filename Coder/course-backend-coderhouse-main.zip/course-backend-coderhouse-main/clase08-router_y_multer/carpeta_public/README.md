# Carpeta public

-   Partiendo del ejercicio anterior, generar una carpeta pública `'public'` en el servidor, la cual tendrá un archivo `index.html`.
-   En ese archivo se encontrarán dos formularios: uno que permita ingresar mascotas y otro personas utilizando el método post
-   Probar el ingreso de datos mediante los formularios y con Postman
-   Verificar los datos cargados en cada caso.
