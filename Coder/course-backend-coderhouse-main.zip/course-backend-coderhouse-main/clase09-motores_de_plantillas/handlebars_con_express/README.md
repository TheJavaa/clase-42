# Handlebars con express

-   Transformar el primer desafío, pero esta vez la página dinámica la creará el servidor desde handlebars instalado y configurado para trabajar con express.
-   Utilizar la misma estructura de plantilla HTML dentro de una pagina web con encabezado y el mismo objeto de datos.
-   El servidor escuchará en el puerto 8080 y el resultado lo ofrecerá en su ruta root.
