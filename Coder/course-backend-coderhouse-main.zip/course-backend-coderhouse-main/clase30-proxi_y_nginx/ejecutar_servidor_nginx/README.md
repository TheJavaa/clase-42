# Ejecutar servidor NGINX

1. Descargar el servidor Nginx y ponerlo en funcionamiento.
2. Verificar que se encuentre corriendo como proceso del sistema operativo.
3. Hacer un request a su ruta raíz y verificar que esté ofreciendo el index.html que se encuentra en carpeta html. Realizar un cambio en dicha html y comprobar que se refleje en el navegador.
4. Integrar un css al index.html que modifique algún estilo del sitio de prueba (Ej. el color de un título). Luego añadir un archivo Javascript que saque un mensaje 'Hola Nginx!!!' por consola. 5 5 5. Verificar que estos cambios se vean al requerir la página.
