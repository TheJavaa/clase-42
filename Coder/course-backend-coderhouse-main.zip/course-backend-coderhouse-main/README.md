# Challenges from [Backend](https://www.coderhouse.com/online/programacion-backend) course at [Coderhouse](https://www.coderhouse.com/)

## Clases

1. Clase 01: Principios de programación backend
2. Clase 02: Principios básicos de JavaScript
3. Clase 03: Programación sincrónica y asincrónica
4. Clase 04: Manejo de archivos en JavaScript
5. Clase 05: Administradores de paquetes NPM
6. Clase 06: Servidores web
7. Clase 07: Express avanzado
8. Clase 08: Router & Multer
9. Clase 09: Motores de plantillas
10. Clase 10: Pug & Ejs
11. Clase 11: Websockets
12. Clase 12: Aplicación chat con websocket
13. Clase 13: Node.js como herramienta de desarrollo
