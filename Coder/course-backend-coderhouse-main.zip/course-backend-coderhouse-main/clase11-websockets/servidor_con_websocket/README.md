# SERVIDOR CON WEBSOCKET

1. Desarrollar un servidor basado en express que tenga integrado Websocket. Con cada conexión de cliente, el servidor debe emitir por consola en mensaje: `¡Nuevo cliente conectado!`

2. Sobre la estructura anteriormente creada, agregar en la vista de cliente un elemento de entrada de texto donde al introducir texto, el mensaje se vea reflejado en todos los clientes conectados en un párrafo por debajo del input.  
   El texto debe ser enviado caracter a caracter y debe reemplazar el mensaje previo.

3. Basado en el ejercicio que venimos realizando, ahora los mensajes enviados por los clientes deberán ser almacenados en el servidor y reflejados por debajo del elemento de entrada de texto cada vez que el usuario haga un envío. La estructura de almacenamiento será un array de objetos, donde cada objeto tendrá la siguiente estructura:  
   `{ socketid: (el socket.id del que envió el mensaje), mensaje: (texto enviado)}`

-   Cada cliente que se conecte recibirá la lista de mensajes completa.
-   Modificar el elemento de entrada en el cliente para que disponga de un botón de envío de mensaje.
-   Cada mensaje de cliente se representará en un renglón aparte, anteponiendo el socket id.

<br/>

![](img/Imagen1.png)

<br />

---

---

<br />

Inicializar el proyecto  
`npm init`

Instalar `express`  
`npm install express`

Instalar `socket.io`  
`npm install socket.io`

Verificar tener instalado `nodemon` de manera global sino instalarlo  
`npm install -g nodemon`

En el `package.json` agregar un script para correr el servidor con `nodemon`

```javascript
"scripts": {
    "dev": "nodemon index.js"
}
```

`index.js` debería ser el nombre del archivo que levanta el servidor

Correr el servidor  
`npm run dev`
