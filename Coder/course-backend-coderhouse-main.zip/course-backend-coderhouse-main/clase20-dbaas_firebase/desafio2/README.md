Realizar un proyecto en Node.js que acceda a una base de datos Firebase ya configurada.

1. Agregar los colores red, green, blue dentro de una colección llamada ‘colores’ con el formato { nombre: color }
2. Listar todos los colores disponibles.
3. Modificar el color blue por navy.
4. Borrar el color green

A tener en cuenta:
Implementar estas funciones utilizando Promises en las funciones de Firebase con sintaxis async/await, utilizando la importación en formato ES Modules (import)
Verificar la información de la base de datos con la consola de Firebase.
