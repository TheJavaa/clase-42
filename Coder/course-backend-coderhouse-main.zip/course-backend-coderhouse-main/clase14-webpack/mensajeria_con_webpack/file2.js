let message2 = 'message2';

setTimeout(() => {
	console.log(message2);
}, 2000);
