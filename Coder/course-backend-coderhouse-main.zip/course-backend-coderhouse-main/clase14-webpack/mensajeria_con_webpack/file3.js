let message3 = 'message3';

setTimeout(() => {
	console.log(message3);
}, 3000);
