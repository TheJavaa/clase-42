let message1 = 'message 1';

setTimeout(() => {
	console.log(message1);
}, 1000);
