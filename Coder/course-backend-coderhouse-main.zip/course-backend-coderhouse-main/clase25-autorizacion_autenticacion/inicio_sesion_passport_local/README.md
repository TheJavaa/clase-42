# Inicio De Sesión Con Passport-local

Realizar el lo visto en el anterior segmento, en esta ocasión utilizando passport con LocalStrategy para realizar todas las funciones que se piden.
No hace falta encriptar las contraseñas ni usar base de datos, todo puede residir en memoria del servidor: usuarios y sesiones.
